package com.project.BankManagerSystem.Controller;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.project.BankManagerSystem.Entity.BankUser;
import com.project.BankManagerSystem.Entity.Role;
import com.project.BankManagerSystem.Exceptions.UserIdNotFoundException;
import com.project.BankManagerSystem.Exceptions.UsernameAlreadyFoundException;
import com.project.BankManagerSystem.Service.BankUserService;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.*;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.user;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.redirectedUrl;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(BankUserController.class)
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)

public class BankUserControllerTests {
    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private BankUserService bankUserService;

    @InjectMocks
    private BankUserController bankUserController;

    private BankUser bankUser;
    private BankUser bankUser1;
    private BankUser nullUser;
    private List<BankUser>users;

    @Mock
    private Model model;



    @BeforeEach
    void setUp() {
        bankUser = new BankUser(1L, "ABC", "123", "abc@gmail.com", "India", Role.USER, 3000L);
        bankUser1 = new BankUser(2L, "C", "123", "c@gmail.com", "India", Role.MANAGER, 3000L);
        users= Arrays.asList(bankUser,bankUser1);
        nullUser= new BankUser(1L, "ABC", "123", "abc@gmail.com", "India", Role.USER, 3000L);

    }

    @Test
    public void viewDetails_SUCCESS()
    {

        when(bankUserService.showDetails()).thenReturn(users);
        String viewName = bankUserController.viewDetails(model);

        verify(bankUserService,times(1)).showDetails();
        verify(model, times(1)).addAttribute("listusers",users);

        assertEquals("userDetails",viewName);

    }

    @Test
    public void addUser_SUCCESS()
    {
        String view= bankUserController.addUser(model);
        verify(model,times(1)).addAttribute(eq("bankUser"), any(BankUser.class));
        assertEquals("new_user",view);

    }


    @Test
    public void saveUser_SUCCESS() throws UsernameAlreadyFoundException
    {
        String result= bankUserController.saveUser(bankUser);
        verify(bankUserService, times(1)).saveDetails(bankUser);

        // Assert: Verify the redirect view name returned
        assertEquals("redirect:/bankApi/showDetails", result);

    }

    @Test
    public void updateForm_SUCCESS()
    {
        when(bankUserService.getUserById(bankUser.getId())).thenReturn(bankUser);
        String view= bankUserController.updateForm(bankUser.getId(), model);

        verify(model,times(1)).addAttribute("bankUser",bankUser);
        assertEquals("update_user",view);
    }




//    @Test
//    public void deleteUser_SUCESS() throws Exception {
//        Long userId = 1L;
//
//        // Mock the deletion logic without interacting with the database
//        doNothing().when(bankUserService).deleteUser(userId);
//
//        // Perform the HTTP delete request with authentication and CSRF token
//        mockMvc.perform(delete("/deleteById/{id}", userId)
//                        .with(csrf()) // Add CSRF token for security
//                        .with(user("C").password("123").roles("MANAGER"))) // Add a mock authenticated user
//                .andExpect(status().is3xxRedirection())  // Expect a redirect status (3xx)
//                .andExpect(redirectedUrl("/bankApi/showDetails"))  // Ensure it redirects to showDetails
//                .andDo(result -> {
//                    // Log the response for debugging
//                    System.out.println("Response: " + result.getResponse().getContentAsString());
//                    System.out.println("Status: " + result.getResponse().getStatus());
//                });
//
//        // Verify that the deleteUser method was called once with the correct ID
//        verify(bankUserService, times(1)).deleteUser(userId);
//    }

    @Test
    void testDeleteUser_UserNotFound() throws Exception {

            Long userId = 1L;

            // Simulate that the user is not found by throwing the exception
            doThrow(UserIdNotFoundException.class).when(bankUserService).deleteUser(userId);

            // Call the controller method and verify the exception is thrown
            assertThrows(UserIdNotFoundException.class, () -> bankUserController.deleteUser(userId));
        }
//    @Test
//    void testUpdateUser() throws Exception {
//        Long userId = 1L;
//
//        // Mock the service call to return an existing user
//        BankUser existingUser = new BankUser();
//        existingUser.setUsername("existing_user");
//        existingUser.setEmail("existing@example.com");
//        existingUser.setAddress("Old Address");
//
//        when(bankUserService.getUserById(userId)).thenReturn(existingUser);
//
//        // Perform the PUT request
//        mockMvc.perform(put("/updateUser/{id}", userId)
//                        .flashAttr("bankUser", bankUser)) // Passing the bankUser as a ModelAttribute
//                .andDo(result -> {
//                    // Log the response for debugging
//                    System.out.println("Response: " + result.getResponse().getContentAsString());
//                    System.out.println("Redirected URL: " + result.getResponse().getRedirectedUrl());
//                })
//                .andExpect(status().is3xxRedirection())
//                .andExpect(redirectedUrl("/bankApi/showDetails")); // Expect a redirect to showDetails
//
//        // Verify that the service update method was called
//        verify(bankUserService, times(1)).updateUser(eq(userId), any(BankUser.class));
//    }


}






