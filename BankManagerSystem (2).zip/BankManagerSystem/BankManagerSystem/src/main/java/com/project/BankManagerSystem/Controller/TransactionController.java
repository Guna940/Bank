package com.project.BankManagerSystem.Controller;

import com.project.BankManagerSystem.DTO.BankUserDTO;
import com.project.BankManagerSystem.Exceptions.InsufficientBalanceException;
import com.project.BankManagerSystem.Exceptions.UserIdNotFoundException;
import com.project.BankManagerSystem.Service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/transaction")
public class TransactionController {

    @Autowired
    private TransactionService transactionService;

    @GetMapping("/showDetails/{id}")
    public String showUserDetails(@PathVariable("id") Long id, Model model) throws UserIdNotFoundException {
        // Get user from the service and convert to DTO
        BankUserDTO userDTO = transactionService.convertToDTO(transactionService.getUserById(id));
        model.addAttribute("user", userDTO);
        return "userDashboard"; // Thymeleaf template for user details
    }

    @PostMapping("/deposit/{id}")
    public String deposit(@PathVariable("id") Long id, @RequestParam("amount") Long amount, Model model) {
            transactionService.deposit(id, amount);
            return "redirect:/transaction/showDetails/" + id; // Redirect to the user details page after deposit

    }

    @PostMapping("/withdraw/{id}")
    public String withdraw(@PathVariable("id") Long id, @RequestParam("amount") Long amount, Model model) throws InsufficientBalanceException {

            transactionService.withdraw(id, amount);
            return "redirect:/transaction/showDetails/" + id; // Redirect to the user details page after withdrawal

    }
}
