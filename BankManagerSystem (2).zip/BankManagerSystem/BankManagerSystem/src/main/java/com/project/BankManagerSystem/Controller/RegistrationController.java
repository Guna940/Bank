package com.project.BankManagerSystem.Controller;

import com.project.BankManagerSystem.Entity.BankUser;
import com.project.BankManagerSystem.Service.BankUserService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/register")
public class RegistrationController {

    private final BankUserService bankUserService;
    private final PasswordEncoder passwordEncoder;

    public RegistrationController(BankUserService bankUserService, PasswordEncoder passwordEncoder) {
        this.bankUserService = bankUserService;
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping
    public String showRegistrationForm(Model model) {
        model.addAttribute("bankUser", new BankUser());
        return "register";  // Thymeleaf template for registration form
    }

    @PostMapping
    public String registerUser(BankUser bankUser) {
        // Hash the password before saving it
        String encodedPassword = passwordEncoder.encode(bankUser.getPassword());
        bankUser.setPassword(encodedPassword);  // Set the hashed password

        bankUser.setBalance(bankUser.getBalance());  // Default balance set to 0
        bankUserService.saveDetails(bankUser);  // Save the user to the database

        return "redirect:/signin";  // Redirect to login page after registration
    }
}
