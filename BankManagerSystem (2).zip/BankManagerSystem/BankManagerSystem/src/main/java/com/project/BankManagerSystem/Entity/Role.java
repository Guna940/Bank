package com.project.BankManagerSystem.Entity;

public enum Role {
    MANAGER,
    USER
}
