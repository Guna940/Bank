package com.project.BankManagerSystem.Controller;

import com.project.BankManagerSystem.Entity.BankUser;
import com.project.BankManagerSystem.Entity.Role;
import com.project.BankManagerSystem.Exceptions.UserIdNotFoundException;
import com.project.BankManagerSystem.Exceptions.UsernameAlreadyFoundException;
import com.project.BankManagerSystem.Service.BankUserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@Controller
@RequestMapping("/bankApi")
@Slf4j
public class BankUserController {


    @Autowired
    BankUserService bankUserService;
    // For showing user details in the view
    @GetMapping("/showDetails")
    public String viewDetails(Model model) {
        model.addAttribute("listusers", bankUserService.showDetails());
        log.info("Showing Details of The User ");
        return "userDetails";
    }

    // For registration form
    @GetMapping("/showNewUserForm")
    public String addUser(Model model) {
        BankUser bankUser = new BankUser();
        model.addAttribute("bankUser", bankUser);
        log.info("New User form");
        return "new_user";
    }

    // Save user (new or update)
    @PostMapping("/saveUser")
    public String saveUser(@ModelAttribute("bankUser") BankUser bankUser) throws UsernameAlreadyFoundException {

            bankUserService.saveDetails(bankUser);
        return "redirect:/bankApi/showDetails";  // Redirect to /showDetails after saving
    }

    // Show form for updating user details
    @GetMapping("/showFormForUpdate/{id}")
    public String updateForm(@PathVariable("id") Long id, Model model) {
        BankUser bankUser = bankUserService.getUserById(id);
        model.addAttribute("bankUser", bankUser);
        return "update_user";
    }

    // Delete user
    @GetMapping("/deleteById/{id}")
    public String deleteUser(@PathVariable("id") Long id) throws UserIdNotFoundException {
        bankUserService.deleteUser(id);
        return "redirect:/bankApi/showDetails";  // Redirect to /showDetails after deleting
    }

    @PutMapping("/updateUser/{id}")
    public String updateUser(@PathVariable("id") Long id, @ModelAttribute("bankUser") BankUser bankUser) throws UserIdNotFoundException {

            BankUser existingUser = bankUserService.getUserById(id);

            // Update the allowed fields
            existingUser.setUsername(bankUser.getUsername());
            existingUser.setEmail(bankUser.getEmail());
            existingUser.setAddress(bankUser.getAddress());

            // Save the updated user
            bankUserService.updateUser(id,existingUser);

        return "redirect:/bankApi/showDetails";  // Redirect to /showDetails after saving
    }



}
