package com.project.BankManagerSystem.Service;

import com.project.BankManagerSystem.Entity.BankUser;
import com.project.BankManagerSystem.Entity.Role;
import com.project.BankManagerSystem.Exceptions.UserIdNotFoundException;
import com.project.BankManagerSystem.Exceptions.UsernameAlreadyFoundException;
import com.project.BankManagerSystem.Repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@ExtendWith(MockitoExtension.class)
public class BankUserServiceTests {

    @Mock
    UserRepository userRepository;

    @InjectMocks
    BankUserService bankUserService;

    private BankUser bankUser;
    private BankUser bankUser1;
    private List<BankUser> users;
    private BankUser existingUser;
    private BankUser updatedUser;
    @BeforeEach
    void setUp() {
        bankUser = new BankUser(1L, "ABC", "123", "abc@gmail.com", "India", Role.USER, 3000L);
        bankUser1 = new BankUser(2L, "C", "123", "c@gmail.com", "India", Role.MANAGER, 3000L);
        users = Arrays.asList(bankUser, bankUser1);

        existingUser = new BankUser(1L, "ABCC", "123", "abCc@gmail.com", "India", Role.USER, 3000L);
        updatedUser = new BankUser(null, "NewUsername", "123", "newemail@gmail.com", "New Address", Role.USER, 3000L);
    }

    // Test showDetails
    @Test
    public void showDetailsTest() {
        when(userRepository.findAll()).thenReturn(users);

        // Optionally, add logic to verify the response if needed, e.g.
        List<BankUser> returnedUsers = bankUserService.showDetails();
        assertNotNull(returnedUsers);
        assertEquals(2, returnedUsers.size());
    }

    // Test saveDetails when the user doesn't exist
    @Test
    public void saveDetailsTest_Success() {
        //arrange
        when(userRepository.findByUsername(bankUser.getUsername())).thenReturn(Optional.empty());
        when(userRepository.save(bankUser)).thenReturn(bankUser);

        //act
        BankUser savedUser = bankUserService.saveDetails(bankUser);

        //assert
        assertNotNull(savedUser);
        assertEquals(bankUser.getUsername(), savedUser.getUsername());
        verify(userRepository, times(1)).save(bankUser);
    }

    // Test saveDetails when the user already exists
    @Test
    public void saveDetailsTest_UserAlreadyExists() {
        when(userRepository.findByUsername(bankUser.getUsername())).thenReturn(Optional.of(bankUser));

        // Use assertThrows to verify that the exception is thrown
        assertThrows(UsernameAlreadyFoundException.class, () -> {
            bankUserService.saveDetails(bankUser);
        });

        verify(userRepository, never()).save(bankUser);  // Ensure save is never called
    }

    @Test
    public void getUserByIdTest_SUCCESS()
    {
        when(userRepository.findById(bankUser.getId())).thenReturn(Optional.of(bankUser));

        BankUser foundUser= bankUserService.getUserById(bankUser.getId());

        assertNotNull(foundUser);
        assertEquals(bankUser.getUsername(), foundUser.getUsername());
        assertEquals(bankUser.getId(), foundUser.getId());

        // Verify that userRepository.findById() was called once with the ID 1
        verify(userRepository, times(1)).findById(1L);
    }

    @Test
    public void getUserById_UserNotFound(){
        // Arrange: Mock userRepository to return an empty Optional when user is not found
        when(userRepository.findById(1L)).thenReturn(Optional.empty());

        // Act & Assert: Verify that the exception is thrown
        assertThrows(UserIdNotFoundException.class, () -> {
            bankUserService.getUserById(1L);
        });

        // Verify that userRepository.findById() was called once with the ID 1
        verify(userRepository, times(1)).findById(1L);
    }

    @Test
    public void deleteUser_SUCCESS()
    {
        when(userRepository.findById(1L)).thenReturn(Optional.of(bankUser));

        bankUserService.deleteUser(1L);

        verify(userRepository, times(1)).deleteById(1L);

    }

    @Test
    public void deleteUserById_UserNotFound(){
        // Arrange: Mock userRepository to return an empty Optional when user is not found
        when(userRepository.findById(1L)).thenReturn(Optional.empty());

        // Act & Assert: Verify that the exception is thrown
        assertThrows(UserIdNotFoundException.class, () -> {
            bankUserService.deleteUser(1L);
        });

        verify(userRepository, never()).deleteById(1L);
    }

    @Test
    public void updateUser_SUCESS()
    {
        // Arrange: Mock userRepository to return the existing user when findById is called
        when(userRepository.findById(1L)).thenReturn(Optional.of(existingUser));

        // Act: Call updateUser to update the user's information
        bankUserService.updateUser(1L, updatedUser);

        // Assert: Verify that the userRepository.save method was called once with the updated user
        verify(userRepository, times(1)).save(existingUser);

        // Assert that the user details are updated correctly
        assertEquals("NewUsername", updatedUser.getUsername());
        assertEquals("newemail@gmail.com", updatedUser.getEmail());
        assertEquals("New Address", updatedUser.getAddress());
    }

    @Test
    public void updateUser_UserNotFound() {
        // Arrange: Mock userRepository to return an empty Optional when user is not found
        when(userRepository.findById(1L)).thenReturn(Optional.empty());

        // Act & Assert: Verify that the exception is thrown
        assertThrows(UserIdNotFoundException.class, () -> {
            bankUserService.updateUser(1L, updatedUser);
        });

        // Verify that save method was never called
        verify(userRepository, never()).save(any());
    }


    @Test
    public void getUserByUsername_SUCCESS()
    {
        when(userRepository.findByUsername("ABC")).thenReturn(Optional.of(bankUser));
        bankUserService.getUserByUsername("ABC");

        assertEquals("ABC",bankUser.getUsername());
        verify(userRepository, times(1)).findByUsername("ABC");


    }

    @Test
    public void getUserByUsername_NOTFOUND()
    {
        when(userRepository.findByUsername("ABC")).thenReturn(Optional.empty());
        assertThrows(UsernameNotFoundException.class,() -> {
            bankUserService.getUserByUsername("ABC");
        });
        verify(userRepository, times(1)).findByUsername("ABC");

    }


}
