package com.project.BankManagerSystem.Controller;

import com.project.BankManagerSystem.Entity.BankUser;
import com.project.BankManagerSystem.Entity.Role;
import com.project.BankManagerSystem.Service.BankUserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
//@WebMvcTest(HomeController.class)
public class HomeControllerTests {

    @Mock
    private BankUserService bankUserService;  // Mock the BankUserService correctly

    @InjectMocks
   HomeController homeController;  // Inject the mocks into the controller

    @Mock
    private Authentication authentication;  // Mock Authentication

    @Autowired
    MockMvc mockMvc;
    @BeforeEach
    void setUp() {
        // Initialize BankUser mock data here if needed

    }
    @Test
    void testHomeManagerRole() throws UsernameNotFoundException {
        // Mocking the Authentication and User
        Authentication mockAuthentication = mock(Authentication.class);
        User mockLoggedInUser = mock(User.class);

        when(mockAuthentication.getPrincipal()).thenReturn(mockLoggedInUser);
        when(mockLoggedInUser.getUsername()).thenReturn("managerUser");

        BankUser bankUser = new BankUser(1L, "managerUser", "123", "abc@gmail.com", "India", Role.MANAGER, 3000L);
        when(bankUserService.getUserByUsername("managerUser")).thenReturn(bankUser);

        // Call the method to be tested
        String result = homeController.home(mockAuthentication);

        // Assertions
        assertEquals("redirect:/bankApi/showDetails", result);
    }

    @Test
    void testHomeUserRole() throws UsernameNotFoundException {
        // Mocking the Authentication and User
        Authentication mockAuthentication = mock(Authentication.class);
        User mockLoggedInUser = mock(User.class);

        when(mockAuthentication.getPrincipal()).thenReturn(mockLoggedInUser);
        when(mockLoggedInUser.getUsername()).thenReturn("user");

        BankUser bankUser = new BankUser(1L, "user", "123", "abc@gmail.com", "India", Role.USER, 3000L);
        when(bankUserService.getUserByUsername("user")).thenReturn(bankUser);

        // Call the method to be tested
        String result = homeController.home(mockAuthentication);

        // Assertions
        assertEquals("redirect:/transaction/showDetails/" + bankUser.getId(), result);
    }

    @Test
    void testHomeWithException() throws UsernameNotFoundException {
        // Mocking the Authentication for a non-existent user
        Authentication mockAuthentication = mock(Authentication.class);
        User mockLoggedInUser = mock(User.class);

        when(mockAuthentication.getPrincipal()).thenReturn(mockLoggedInUser);
        when(mockLoggedInUser.getUsername()).thenReturn("nonExistentUser");

        when(bankUserService.getUserByUsername("nonExistentUser")).thenThrow(new UsernameNotFoundException("User not found"));

        // Call the method and assert that it throws an exception
        assertThrows(UsernameNotFoundException.class, () -> homeController.home(mockAuthentication));
    }


}
