package com.project.BankManagerSystem.Service;

import com.project.BankManagerSystem.Entity.BankUser;
import com.project.BankManagerSystem.Repository.UserRepository;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class CustomerUserDetailsService implements UserDetailsService {

    private final UserRepository userRepository;

    public CustomerUserDetailsService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        BankUser bankUser = userRepository.findByUsername(username)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));

        // Spring Security will automatically use BCryptPasswordEncoder for password matching
        return User.builder()
                .username(bankUser.getUsername())
                .password(bankUser.getPassword())  // The hashed password from DB
                .roles(bankUser.getRole().name())  // User role (MANAGER/USER)
                .build();
    }
}
