package com.project.BankManagerSystem.Repository;

import com.project.BankManagerSystem.Entity.BankUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<BankUser,Long> {

    Optional<BankUser> findByUsername(String username);

    // Deposit operation using @Modifying and @Query
    @Modifying
    @Query("update BankUser set balance = balance + :amount where id = :id")
    void deposit(@Param("id") Long id, @Param("amount") Long amount);

    // Withdraw operation using @Modifying and @Query
    @Modifying
    @Query("update BankUser set balance = balance - :amount where id = :id")
    void withdraw(@Param("id") Long id, @Param("amount") Long amount);

    // Retrieve balance using a @Query
    @Query("select balance from BankUser where id = :id")
    Long findBalanceById(@Param("id") Long id);

}
