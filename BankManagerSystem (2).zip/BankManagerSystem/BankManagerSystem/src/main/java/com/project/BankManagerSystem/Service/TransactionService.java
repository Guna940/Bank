package com.project.BankManagerSystem.Service;

import com.project.BankManagerSystem.DTO.BankUserDTO;
import com.project.BankManagerSystem.Entity.BankUser;
import com.project.BankManagerSystem.Exceptions.InsufficientBalanceException;
import com.project.BankManagerSystem.Exceptions.UserIdNotFoundException;
import com.project.BankManagerSystem.Repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
public class TransactionService {

    @Autowired
    private UserRepository userRepository;

    // Deposit logic using @Modifying and @Query in the repository
    @Transactional
    public void deposit(Long userId, Long amount) {
        userRepository.deposit(userId, amount);
    }

    // Withdraw logic using @Modifying and @Query in the repository
    @Transactional
    public String withdraw(Long userId, Long amount) {
        Optional<BankUser> optionalBankUser = userRepository.findById(userId);

        if (!optionalBankUser.isPresent()) {
            throw new UserIdNotFoundException("User not found");
        }

        BankUser bankUser = optionalBankUser.get();

        // Check if the user has sufficient balance
        if (userRepository.findBalanceById(bankUser.getId()) < amount) {
            // Handle insufficient funds: return a message, throw an exception, etc.
            throw new InsufficientBalanceException("Insufficient balance for the withdrawal");
        }

        // If sufficient balance, perform the withdrawal
        userRepository.withdraw(userId, amount);

        // Return a success message or updated bank user
        return "Withdrawal successful!";
    }

    // Convert BankUser to BankUserDTO-Mapper
    public BankUserDTO convertToDTO(BankUser user) {
        return new BankUserDTO(
                user.getId(),
                user.getUsername(),
                user.getEmail(),
                user.getBalance());
    }

    // Fetch user by ID for converting to DTO
    public BankUser getUserById(Long id) {
        return userRepository.findById(id).orElseThrow(() -> new UserIdNotFoundException("User not found"));
    }
}
