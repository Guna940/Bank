package com.project.BankManagerSystem.Repository;

import com.project.BankManagerSystem.Entity.BankUser;
import com.project.BankManagerSystem.Entity.Role;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.util.Optional;

import static org.assertj.core.api.Assertions.as;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)

public class UserRepositoryTests {

    @Mock
    UserRepository userRepository;

    private BankUser bankUser;

    @BeforeEach
    void setUp() {
        bankUser = new BankUser(1L, "ABC", "123", "abc@gmail.com", "India", Role.USER, 3000L);
    }


    @Test
    public void findByUsername_SUCCESS()
    {
        when(userRepository.findByUsername("ABC")).thenReturn(Optional.of(bankUser));
        Optional<BankUser> result = userRepository.findByUsername("ABC");

        assertTrue(result.isPresent());

        assertEquals("ABC",bankUser.getUsername());

        verify(userRepository,times(1)).findByUsername("ABC");
    }

    @Test
    public void findByUsername_NotFound()
    {
        when(userRepository.findByUsername("ABCC")).thenReturn(Optional.empty());

        Optional<BankUser> user=userRepository.findByUsername("ABCC");
        assertThat(user).isNotPresent();
        verify(userRepository,times(1)).findByUsername("ABCC");
    }

    @Test
    void testDeposit_balanceUpdatedCorrectly() {
        Long amount = 500L;

        // Arrange: Mock the repository interaction
        when(userRepository.findById(1L)).thenReturn(Optional.of(bankUser));
//        doNothing().when(userRepository).deposit(1L, amount);

        // Act: Call the deposit method to update the balance
       userRepository.deposit(1L, amount);

       bankUser.setBalance(bankUser.getBalance()+amount);
        // Assert: Verify that the balance is updated correctly
        assertEquals(3500L, bankUser.getBalance()); // 1000 (initial) + 500 (deposit)
    }

    @Test
    public void testWithdraw_whenSufficientBalance()
    {
        Long amount=500L;
        when(userRepository.findById(1L)).thenReturn(Optional.of(bankUser));

        userRepository.withdraw(1L,amount);
        //checking by withdrawing the amount
        bankUser.setBalance(bankUser.getBalance()-amount);

        assertEquals(2500L,bankUser.getBalance());
    }

    @Test
    void testWithdraw_whenInsufficientBalance() {
        Long amount = 1500L;

        // Arrange: Mock the repository interaction for a withdrawal with insufficient funds
        when(userRepository.findById(1L)).thenReturn(Optional.of(bankUser));

        // Act: Try calling the withdraw method with an amount greater than the balance
        userRepository.withdraw(1L, amount);

    //checking by doing nothing
        // Assert: Ensure that the balance remains unchanged since there's insufficient balance
        assertEquals(3000L, bankUser.getBalance()); // Balance should remain 1000
        verify(userRepository, times(1)).withdraw(1L, amount);
    }

    @Test
    public void testfindBalanceById_whenUserExists()
    {
        when(userRepository.findBalanceById(1L)).thenReturn(bankUser.getBalance());

        userRepository.findBalanceById(1L);

        assertEquals(3000L,bankUser.getBalance());
        verify(userRepository,times(1)).findBalanceById(1L);
    }

    @Test
    public void testfindBalanceById_UserNotFound()
    {

        when(userRepository.findBalanceById(1L)).thenReturn(null);

        Long balance = userRepository.findBalanceById(1L);

        // Assert: Verify the result is null or default value
        assertNull(balance);


    }

}
