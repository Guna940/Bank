package com.project.BankManagerSystem.Controller;

import com.project.BankManagerSystem.DTO.BankUserDTO;
import com.project.BankManagerSystem.Entity.BankUser;
import com.project.BankManagerSystem.Entity.Role;
import com.project.BankManagerSystem.Exceptions.UserIdNotFoundException;
import com.project.BankManagerSystem.Service.TransactionService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@WebMvcTest(TransactionController.class)  // Fix: Use the actual controller class
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class TransactionControllerTests {

    @MockBean
    private TransactionService transactionService;  // Mock the service layer

    @InjectMocks
    private TransactionController transactionController;  // Inject the controller

    @Autowired
    private MockMvc mockMvc;  // Used for web layer testing

    @Mock
    private Model model;  // Mock Model to test attributes added to it

    private BankUserDTO bankUserDTO;
    private BankUser bankUser;

    @BeforeEach
    void setUp() {
        // Initialize DTO object with sample data
        bankUserDTO = new BankUserDTO(1L, "ABC", "123", 3000L);
        bankUser = new BankUser(1L, "ABC", "123", "abc@gmail.com", "India", Role.USER, 3000L);

    }

    @Test
    public void showUserDetails_userFound() throws Exception {
        // Arrange: Mock service calls
        when(transactionService.getUserById(1L)).thenReturn(bankUser);
        when(transactionService.convertToDTO(bankUser)).thenReturn(bankUserDTO);

        // Act: Call the controller method
        String view = transactionController.showUserDetails(1L, model);

        // Assert: Verify that the correct view is returned and the model has the user
        verify(model).addAttribute("user", bankUserDTO);
        assertEquals("userDashboard", view);
    }

    @Test
    void showUserDetails_ShouldThrowException_WhenUserNotFound() throws UserIdNotFoundException {
        // Arrange: Mock the service to throw an exception
        when(transactionService.getUserById(1L)).thenThrow(new UserIdNotFoundException("User Id not found"));

        // Act & Assert: Check that the exception is thrown
        assertThrows(UserIdNotFoundException.class, () -> {
           transactionController.showUserDetails(1L, model);
        });
    }




}
