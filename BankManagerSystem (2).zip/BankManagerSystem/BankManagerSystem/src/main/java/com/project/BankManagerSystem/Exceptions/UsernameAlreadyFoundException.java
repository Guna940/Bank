package com.project.BankManagerSystem.Exceptions;

public class UsernameAlreadyFoundException extends RuntimeException
{
    public UsernameAlreadyFoundException(String message) {
        super(message);
    }
}
