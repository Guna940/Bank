package com.project.BankManagerSystem.Service;


import com.project.BankManagerSystem.Entity.BankUser;
import com.project.BankManagerSystem.Entity.Role;
import com.project.BankManagerSystem.Repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class CustomerUserDetailsServiceTests {

    @Mock
    UserRepository userRepository;

    @InjectMocks
    CustomerUserDetailsService customerUserDetailsService;

    private BankUser bankUser;

    @BeforeEach
    void setUp() {
        bankUser = new BankUser(1L, "ABC", "123", "abc@gmail.com", "India", Role.USER, 3000L);
    }

    @Test
    public void loadByUserName_SUCCESS(){
        when(userRepository.findByUsername("ABC")).thenReturn(Optional.of(bankUser));

        UserDetails userDetails=customerUserDetailsService.loadUserByUsername(bankUser.getUsername());
        assertNotNull(userDetails);
        assertEquals(bankUser.getUsername(), userDetails.getUsername());
        assertEquals(bankUser.getPassword(), userDetails.getPassword());
        assertTrue(userDetails.getAuthorities().stream().anyMatch(grantedAuthority -> grantedAuthority.getAuthority().equals("ROLE_" + bankUser.getRole().name())));

        // Verify that the repository method was called once
        verify(userRepository, times(1)).findByUsername(bankUser.getUsername());


    }

    @Test
    public void loadByUserName_UserNameNotFound()
    {
        when(userRepository.findByUsername("ABC")).thenReturn(Optional.empty());
        assertThrows(UsernameNotFoundException.class,
                ()-> customerUserDetailsService.loadUserByUsername("ABC"));
        verify(userRepository,times(1)).findByUsername("ABC");
    }

}
