package com.project.BankManagerSystem.Service;

import com.project.BankManagerSystem.Entity.BankUser;
import com.project.BankManagerSystem.Exceptions.UserIdNotFoundException;
import com.project.BankManagerSystem.Exceptions.UsernameAlreadyFoundException;
import com.project.BankManagerSystem.Repository.UserRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BankUserService {

    @Autowired
    UserRepository userRepository;


    //1.Show ALL Users
    public List<BankUser> showDetails()
    {
        return userRepository.findAll();
    }

    //2. Save Users
    public BankUser  saveDetails(BankUser bankUser)
    {
        Optional<BankUser> user= userRepository.findByUsername(bankUser.getUsername());
        if(user.isPresent())
        {
            throw new UsernameAlreadyFoundException("Username Already Present");
        }
        else {
           return userRepository.save(bankUser);
        }

    }

    //3. Get UserByID
    public BankUser getUserById(Long id)
    {
        Optional<BankUser> user= userRepository.findById(id);
        BankUser bankUser = null;

        if(user.isPresent())
        {
            bankUser=user.get();
        }
        else {
            throw new UserIdNotFoundException("User id not present");
        }
        return bankUser;
    }

    //4. DeleteUser
    public void deleteUser(Long id)
    {
        Optional<BankUser> user= userRepository.findById(id);
        if(user.isPresent()) {
            userRepository.deleteById(id);
        }
        else {
            throw new UserIdNotFoundException("User id not found");
        }

    }
    @Transactional
    public void updateUser(Long id, BankUser bankUser) throws UserIdNotFoundException {
        // Find the user by ID

        Optional<BankUser> existingUserOpt = userRepository.findById(id);
        if (existingUserOpt.isEmpty()) {
            throw new UserIdNotFoundException("User ID " + id + " not found.");
        }

        BankUser existingUser = existingUserOpt.get();

        // Update allowed fields (username, email, and address)
        existingUser.setUsername(bankUser.getUsername());
        existingUser.setEmail(bankUser.getEmail());
        existingUser.setAddress(bankUser.getAddress());

        // Save the updated user (password, role, balance remain unchanged)
        userRepository.save(existingUser);
    }

    public BankUser getUserByUsername(String username) {
        Optional<BankUser> user = userRepository.findByUsername(username);
        if (user.isPresent()) {
            return user.get();
        } else {
            throw new UsernameNotFoundException("User not found");
        }
    }

}




