package com.project.BankManagerSystem.Config;

import com.project.BankManagerSystem.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    private final UserRepository userRepository;

    public SecurityConfig(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Autowired
    private UserDetailsService userDetailsService;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable()) // Disable CSRF for simplicity
                .authorizeRequests(auth -> auth
                        .requestMatchers("/register", "/signin").permitAll() // Allow /register and /login URLs
                                .requestMatchers("/favicon.ico").permitAll()
                                .requestMatchers("/bankApi/showDetails").hasRole("MANAGER")  // Only MANAGER role can access this endpoint
                                .requestMatchers("/bankApi/deleteById/**").hasRole("MANAGER")
                               .requestMatchers("/transaction/user/**").hasRole("USER")  // Only USER role can access their transaction endpoint
                          // Any other request requires authentication
                )
                .formLogin(form -> form
                        .loginPage("/signin")  // Custom login page URL
                        .defaultSuccessUrl("/home", true)  // Redirect after successful login
                        .permitAll()  // Allow access to the login page
                );
                 // Enable HTTP Basic Authentication as a fallback (optional)

        return http.build();
    }

    @Bean
    public AuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setPasswordEncoder(passwordEncoder()); // Password decoder
        provider.setUserDetailsService(userDetailsService); // Set custom UserDetailsService
        return provider;
    }
}
