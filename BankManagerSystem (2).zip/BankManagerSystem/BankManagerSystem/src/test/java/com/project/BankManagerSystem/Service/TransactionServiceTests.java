package com.project.BankManagerSystem.Service;

import com.project.BankManagerSystem.DTO.BankUserDTO;
import com.project.BankManagerSystem.Entity.BankUser;
import com.project.BankManagerSystem.Entity.Role;
import com.project.BankManagerSystem.Exceptions.InsufficientBalanceException;
import com.project.BankManagerSystem.Exceptions.UserIdNotFoundException;
import com.project.BankManagerSystem.Repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class TransactionServiceTests {
    @Mock
    UserRepository userRepository;

    @InjectMocks
    TransactionService transactionService;

    private BankUser bankUser;
    private BankUser bankUser1;

    @BeforeEach
    void setUp() {
        bankUser = new BankUser(1L, "ABC", "123", "abc@gmail.com", "India", Role.USER, 3000L);
        bankUser1 = new BankUser(2L, "C", "123", "c@gmail.com", "India", Role.MANAGER, 3000L);
    }

    @Test
    public void deposit_SUCESS()
    {
        // Act: Call deposit method to deposit the amount
        transactionService.deposit(1L, 500L);

       //doNothing().when(userRepository).deposit(1L,500L);
        bankUser.setBalance(bankUser.getBalance()+500L);
        // Assert: Verify that the deposit method was called once with the correct userId and amount
        verify(userRepository, times(1)).deposit(1L, 500L);


        // Verify that the user's balance is updated correctly
        assertEquals(3500L, bankUser.getBalance());
    }

    @Test
    public void withdraw_SUCCESS() {
        // Arrange: Mock repository to return a BankUser with sufficient balance
        when(userRepository.findById(1L)).thenReturn(Optional.of(bankUser));
        when(userRepository.findBalanceById(bankUser.getId())).thenReturn(3000L);  // Ensure sufficient balance

        doNothing().when(userRepository).withdraw(1L, 500L);  // Mock the withdraw operation

        // Act: Call withdraw method to simulate withdrawal
        String result = transactionService.withdraw(1L, 500L);

        // Assert: Verify the success message is returned
        assertEquals("Withdrawal successful!", result);

        // Verify that the withdraw method was called once with the correct parameters
        verify(userRepository, times(1)).withdraw(1L, 500L);
    }

    @Test
    public void withdraw_InsufficientBalance()
    {
        when(userRepository.findById(1L)).thenReturn(Optional.of(bankUser));
        assertThrows(InsufficientBalanceException.class,
                () -> transactionService.withdraw(1L, 3500L));

        verify(userRepository, never()).withdraw(anyLong(), anyLong());

    }
    @Test
    public void withdraw_UserNotFound() {
        // Arrange: Mock the repository to return an empty Optional when looking for the user
        when(userRepository.findById(1L)).thenReturn(Optional.empty());

        // Act & Assert: Verify that UserIdNotFoundException is thrown
        assertThrows(UserIdNotFoundException.class,
                () -> transactionService.withdraw(1L, 500L));

        // Verify that withdraw method was not called
        verify(userRepository, never()).withdraw(anyLong(), anyLong());
    }

    @Test
    public void getByUserId_SUCCESS()
    {
        when(userRepository.findById(1L)).thenReturn(Optional.of(bankUser));
        transactionService.getUserById(1L);
        assertEquals(1L,bankUser.getId());
    }

    @Test
    public void getByUserId_IdNotFound()
    {
        when(userRepository.findById(1L)).thenReturn(Optional.empty());

        assertThrows(UserIdNotFoundException.class,()->
                transactionService.getUserById(1L));

        verify(userRepository,times(1)).findById(1L);
    }

    @Test
    public void testConvertToDTO() {
        // Act: Convert the BankUser to BankUserDTO
        BankUserDTO bankUserDTO =transactionService.convertToDTO(bankUser);

        // Assert: Verify the BankUserDTO has the same properties as the original BankUser
        assertEquals(bankUser.getId(), bankUserDTO.getId());
        assertEquals(bankUser.getUsername(), bankUserDTO.getUsername());
        assertEquals(bankUser.getEmail(), bankUserDTO.getEmail());
        assertEquals(bankUser.getBalance(), bankUserDTO.getBalance());
    }
}
