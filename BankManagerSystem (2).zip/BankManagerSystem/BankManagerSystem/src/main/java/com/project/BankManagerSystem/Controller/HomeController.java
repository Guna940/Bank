package com.project.BankManagerSystem.Controller;

import com.project.BankManagerSystem.Entity.BankUser;
import com.project.BankManagerSystem.Service.BankUserService;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController {

    private final BankUserService bankUserService;

    public HomeController(BankUserService bankUserService) {
        this.bankUserService = bankUserService;
    }

    @GetMapping("/home")
    public String home(Authentication authentication) throws UsernameNotFoundException {
        User loggedInUser = (User) authentication.getPrincipal();
        BankUser user = bankUserService.getUserByUsername(loggedInUser.getUsername());

        // Redirect based on the user's role
        if (user.getRole().name().equals("MANAGER")) {
            return "redirect:/bankApi/showDetails";  // Redirect to manager's page
        } else {
            return "redirect:/transaction/showDetails/" + user.getId();  // Redirect to user's transaction page
        }

    }
    @GetMapping("/signin")
    public String showLoginForm(){
        return "signin";  // Thymeleaf template located in /src/main/resources/templates/signin.html
    }
}
